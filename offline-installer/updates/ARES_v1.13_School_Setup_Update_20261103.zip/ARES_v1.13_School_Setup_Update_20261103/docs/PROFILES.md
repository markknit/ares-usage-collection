# Production and permanent test profiles

Production is the default and uses `ares.local`. The permanent test package uses
`ares-test.local`. Existing online-demo configuration is not deployed or changed.
Build separate sealed bundles; do not edit a field package after SHA256SUMS is made.

```bash
bash build_offline_bundle.sh --source /path/to/source --output /path/to/output --profile production
bash build_offline_bundle.sh --source /path/to/source --output /path/to/output --profile test --apk /path/to/approved-test-profile.apk
```

`package.conf` is the canonical approved release/profile manifest. All runtime
entry points read it; environment overrides cannot silently change a sealed
profile. The mDNS alias is independent of Linux/Tailscale hostname and school code.
Test uses a distinct bundle suffix and separate Android application identity.

Avahi publishes the selected alias using an eligible LAN IPv4 address. Nginx
replaces only the two ARES profile aliases and preserves other server names.
An existing separately configured online demo remains on its production profile.
Do not activate both profiles on the same server or deploy either over the demo.

Lesson3 `ADMIN_URL` uses the selected alias and port 3001. In upstream v0.94,
`SERVER_URL` enables strict public posture, including empty-user boot refusal.
The canonical manifest explicitly keeps it empty for both offline HTTP profiles,
as required by the packaged upstream `.env.example`. This parameter is checked
alongside ADMIN_URL; changing the public security posture needs a separate review.
A healthy existing deployment with different URLs/version is refused rather than
silently migrated or overwritten.

The builder renders static HTML/HTML fragments, teacher pages, JS, JSON and
Markdown links, including encoded tracker targets, before checksum generation.
Collection/export server endpoints use relative paths; central HTTPS upload and
school identity are independent of this alias. Existing public school JSON examples
remain production examples. Generate test fixtures using
`tools/build_school_assets.py --server http://ares-test.local` in an isolated root.

Android builds:

```bash
gradle -p android/ares-sync :app:assembleDebug
gradle -p android/ares-sync :app:assembleDebug -ParesProfile=test
```

Production uses `org.areseducation.sync`; test uses `org.areseducation.sync.test`.
Collection and reachability URLs compile from the selected host. Cleartext is
allowed only for that profile's literal domain in network-security XML.
The builder rejects APKs containing the other profile's collection endpoints.
Use a reviewed signed test APK for an actual field/test package; locally built
debug APKs are not production-approved releases.

Full builds regenerate both printed rollout guides from the rendered profile
Markdown, update the embedded guide copies, and regenerate their checksum manifest.
The Lesson3 reference PDF contains no production-alias URL and remains unchanged.
Build-machine Python requires ReportLab; the field installer needs no PDF tooling.
See `LOCAL_ALIAS_AUDIT.md` for every tracked text occurrence and `PROFILE_ACCEPTANCE.md`
for remaining physical/client/target gates.

v1.13 installs validated TsavoTrust content from the normalized external build
source for both profiles. Its reviewed installer uses relative module URLs and
the selected profile Host header; the old installer is excluded. See
[Tsavo Trust](TSAVO_TRUST.md). Missing or invalid required Tsavo content fails the
build/preflight rather than silently omitting the module. No checksum-bypass
wrapper is copied. Earlier v1.12 evidence remains historical and unchanged.

## School hostname alongside the shared alias

Production keeps the existing Linux hostname (for example `tsavo3`) and Avahi's
`tsavo3.local`, adds `ares.local`, and includes both in the ARES Nginx site.
The test profile instead adds `ares-test.local`. The publisher waits for an
address, supports a link-local LAN without DHCP, follows address changes and
retries a failed publisher. It does not need Internet. Use only one shared
`ares.local` on a given LAN; a name collision cannot give two servers that same
unambiguous address. Linux/Tailscale hostname changes remain separate actions.
